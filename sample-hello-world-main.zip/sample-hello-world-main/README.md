# sample-hello-world
Sample app for POC purposes
